# Chandra Solusindo BOQ - Build APK dari HP

Project ini sudah disiapkan untuk dibuat menjadi APK menggunakan GitHub Actions, jadi Anda tidak perlu memasang Android Studio.

## Langkah dari HP Android

1. Buat akun/login di GitHub.
2. Buat repository baru, misalnya `ChandraSolusindoBOQ`.
3. Upload **seluruh isi folder project ini** ke repository (bukan file ZIP sebagai satu file).
4. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
5. Buka tab **Actions** pada repository.
6. Pilih workflow **Build Android APK**.
7. Tekan **Run workflow** jika workflow belum berjalan otomatis.
8. Tunggu sampai status berubah menjadi hijau (**success**).
9. Buka hasil workflow tersebut dan bagian **Artifacts**.
10. Download `ChandraSolusindoBOQ-debug-apk.zip`.
11. Ekstrak ZIP di HP, lalu install `app-debug.apk`.

Jika Android meminta izin memasang aplikasi dari sumber ini, aktifkan izin tersebut untuk aplikasi File/Browser yang Anda gunakan, lalu ulangi instalasi.

## Catatan
- APK debug cocok untuk pemasangan pribadi/testing.
- Project memakai Android Gradle Plugin 8.5.2, compile/target SDK 35, dan Java 17.
- Aplikasi memuat HTML lokal dari `assets`, sehingga fungsi utama tidak bergantung pada CDN/internet saat digunakan.
