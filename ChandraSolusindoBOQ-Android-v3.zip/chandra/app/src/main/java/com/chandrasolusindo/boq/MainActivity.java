package com.chandrasolusindo.boq;

import android.app.*;import android.os.*;import android.print.*;import android.webkit.*;import android.widget.Toast;import android.view.*;

public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"Android"); setContentView(web); web.loadUrl("file:///android_asset/index.html");}
 public class Bridge { @JavascriptInterface public void printPage(String title){ runOnUiThread(()->{ PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); PrintDocumentAdapter a=web.createPrintDocumentAdapter(title); pm.print(title,a,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()); }); } @JavascriptInterface public void toast(String s){runOnUiThread(()->Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show());}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
